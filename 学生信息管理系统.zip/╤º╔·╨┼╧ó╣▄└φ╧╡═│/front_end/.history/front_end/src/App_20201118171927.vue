<template>
  <div id="app">
  
  <router-view/>
  </div>
</template>
<script>
import user from './components/user'
export default {
  data(){
    return {
    
    }
  }

}
</script>
