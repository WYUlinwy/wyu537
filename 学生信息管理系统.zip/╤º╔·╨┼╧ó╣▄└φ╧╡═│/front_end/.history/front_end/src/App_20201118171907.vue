<template>
  <div id="app">
  
  <router-view/>
  </div>
</template>
<script>
import user from '../user.vue'
export default {
  data(){
    return {
    
    }
  }

}
</script>
