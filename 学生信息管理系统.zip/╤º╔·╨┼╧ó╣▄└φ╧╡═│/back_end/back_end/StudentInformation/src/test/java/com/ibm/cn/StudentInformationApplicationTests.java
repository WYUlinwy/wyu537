package com.ibm.cn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
